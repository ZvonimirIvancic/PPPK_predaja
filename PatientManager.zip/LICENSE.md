Licensed under the Non-Profit Open Software License version 3.0 (NPOSL-3.0)

You may use, copy, modify, and distribute this software for non-profit purposes only.
Commercial use is prohibited without explicit permission from the copyright holder.
