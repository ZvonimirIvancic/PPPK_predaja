﻿namespace PrviProjekt.DTOs
{
    public class CreateSlikaDto
    {
        public int PregledId { get; set; }
        public string? Opis { get; set; }
    }
}
