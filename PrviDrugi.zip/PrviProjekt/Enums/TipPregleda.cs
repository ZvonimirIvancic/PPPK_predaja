﻿namespace PrviProjekt.Enums
{
    public enum TipPregleda
    {
        GP,
        KRV,
        XRAY,
        CT,
        MR,
        ULTRA,
        EKG,
        ECHO,
        EYE,
        DERM,
        DENTA,
        MAMMO,
        NEURO
    }
}
