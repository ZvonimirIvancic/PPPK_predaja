﻿namespace DrugiProjekt.Services
{
    public class PatientDataService
    {
    }
}
