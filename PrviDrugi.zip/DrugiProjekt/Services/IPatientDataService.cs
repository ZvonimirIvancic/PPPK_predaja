﻿namespace DrugiProjekt.Services
{
    public interface IPatientDataService
    {
    }
}
