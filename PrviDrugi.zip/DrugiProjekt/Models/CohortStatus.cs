﻿namespace DrugiProjekt.Models
{
    public enum CohortStatus
    {
        Discovered,
        Downloading,
        Downloaded,
        Processing,
        Completed,
        Failed
    }
}
