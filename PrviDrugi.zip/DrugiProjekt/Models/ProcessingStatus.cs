﻿namespace DrugiProjekt.Models
{
    public enum ProcessingStatus
    {
        Pending,
        Processing,
        Completed,
        Failed
    }
}
